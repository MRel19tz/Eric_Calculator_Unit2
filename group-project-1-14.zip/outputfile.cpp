#include "outputfile.h"
#include <iostream>
#include <regex>
#include <cmath>
#include <thread>

void order_array(double array[], int n);
////////////RCF
void terminal_RCf(double out);
void file_RCf(double out);
int count_lines_RCf();
void read_into_array_RCf(double array[], int n);
void write_array_to_file_RCf(double array[], int n);

////////////RCR
void terminal_RCr(double out);
void file_RCr(double out);
int count_lines_RCr();
void read_into_array_RCr(double array[], int n);
void write_array_to_file_RCr(double array[], int n);

////////////RCC
void terminal_RCc(double out);
void file_RCc(double out);
int count_lines_RCc();
void read_into_array_RCc(double array[], int n);
void write_array_to_file_RCc(double array[], int n);

/////////////RLF
void terminal_RLf(double out);
void file_RLf(double out);
int count_lines_RLf();
void read_into_array_RLf(double array[], int n);
void write_array_to_file_RLf(double array[], int n);

////////////RLR
void terminal_RLr(double out);
void file_RLr(double out);
int count_lines_RLr();
void read_into_array_RLr(double array[], int n);
void write_array_to_file_RLr(double array[], int n);

////////////RLL
void terminal_RLl(double out);
void file_RLl(double out);
int count_lines_RLl();
void read_into_array_RLl(double array[], int n);
void write_array_to_file_RLl(double array[], int n);

/////////////RLCF
void terminal_RLCf(double out);
void file_RLCf(double out);
int count_lines_RLCf();
void read_into_array_RLCf(double array[], int n);
void write_array_to_file_RLCf(double array[], int n);

/////////////RLCC
void terminal_RLCc(double out);
void file_RLCc(double out);
int count_lines_RLCc();
void read_into_array_RLCc(double array[], int n);
void write_array_to_file_RLCc(double array[], int n);

/////////////RLCL
void terminal_RLCl(double out);
void file_RLCl(double out);
int count_lines_RLCl();
void read_into_array_RLCl(double array[], int n);
void write_array_to_file_RLCl(double array[], int n);

///////////////////
void choose_output_menu(){
  std::cout << "\n\033[41m------- Select Output Method -------\033[40;37m\n";
  std::cout << "\033[41m                                    \033[40;37m\n";
  std::cout << "\033[47;30m                                    \033[40;37m\n";
  std::cout << "\033[47;30m    1️⃣   Output on the terminal      \033[40;37m\n";
  std::cout << "\033[47;30m                                    \033[40;37m\n";
  std::cout << "\033[47;30m    2️⃣   Output to txt file          \033[40;37m\n";
  std::cout << "\033[47;30m                                    \033[40;37m\n";
  std::cout << "\033[47;30m🙋               Choose 1️⃣  or 2️⃣  👇:\033[40;37m\n";
}

int get_input_voltagedivider(){
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 6;
  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    // if input is not an integer, print an error message
    if (valid_input == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input = std::stof(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔\033[1;40;31m Invalid menu item\033[1;40;37m\n";
        valid_input = false;
      }
    }
  } while (valid_input == false);
  return input;
}

int get_input2(){
 int input2;
  std::string input2_string;
  bool valid_input2 = false;
  int menu_items = 2;
  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input2_string;
    valid_input2 = is_integer(input2_string);
    // if input is not an integer, print an error message
    if (valid_input2 == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input2 = std::stof(input2_string);
    }
      if (input2 >= 1 && input2 <= menu_items) {
        valid_input2 = true;
      } else {
        std::cout << "😔 ";
        std::cout << "😔\033[1;40;31m Invalid menu item\033[1;40;37m\n";
    }
  } while (valid_input2 == false);

  return input2;

}

void select_load_item_RCf(int input2) {
  switch (input2) {
    case 1:
      terminal_RCf(out);
      break;
    case 2:
      file_RCf(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RCf (double out){
  std::cout <<"🌸The value of you want is: " << out <<"Hz" <<std::endl;
}

void file_RCf (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_f.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RC_f.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RCf();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RCf(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RCf(array, n);
  }
  
}

int count_lines_RCf() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RC_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RCf(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RC_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}

void order_array(double array[], int n) {
  std::sort(array, array + n);  // ascending
  // std::sort(array, array + n, std::greater<int>());  // descending
}

void write_array_to_file_RCf(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_f_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

////////////////////////
////////////////////////
//RCr
void select_load_item_RCr(int input2) {
  switch (input2) {
    case 1:
      terminal_RCr(out);
      break;
    case 2:
      file_RCr(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RCr (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RCr (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_r.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RC_r.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RCr();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RCr(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RCr(array, n);
  }
  
}

int count_lines_RCr() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RC_r.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RCr(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RC_r.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}

void write_array_to_file_RCr(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_r_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

/////////////////////////
/////////////////////////
//RCc
void select_load_item_RCc(int input2) {
  switch (input2) {
    case 1:
      terminal_RCc(out);
      break;
    case 2:
      file_RCc(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RCc (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RCc (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_c.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RC_c.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RCc();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RCc(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RCc(array, n);
  }
  
}

int count_lines_RCc() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RC_c.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RCc(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RC_c.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}

void write_array_to_file_RCc(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RC_c_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

////////////////////
////////////////////
//RLf
void select_load_item_RLf(int input2) {
  switch (input2) {
    case 1:
      terminal_RLf(out);
      break;
    case 2:
      file_RLf(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLf (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RLf (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_f.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RL_f.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RLf();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLf(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLf(array, n);
  }
  
}

int count_lines_RLf() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RL_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLf(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RL_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}

void write_array_to_file_RLf(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_f_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

/////////////////////
/////////////////////
//RLr
void select_load_item_RLr(int input2) {
  switch (input2) {
    case 1:
      terminal_RLr(out);
      break;
    case 2:
      file_RLr(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLr (double out){
  std::cout <<"The value of you want is" << out <<std::endl;
}

void file_RLr (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_r.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RL_r.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RLr();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLr(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLr(array, n);
  }
  
}

int count_lines_RLr() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RL_r.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLr(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RL_r.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}



void write_array_to_file_RLr(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_r_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

////////////////////////////
////////////////////////////
//RLl
void select_load_item_RLl(int input2) {
  switch (input2) {
    case 1:
      terminal_RLl(out);
      break;
    case 2:
      file_RLl(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLl (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RLl (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_l.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RL_l.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9😃:\n";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RLl();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLl(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLl(array, n);
  }
  
}

int count_lines_RLl() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RL_l.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLl(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RL_l.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}



void write_array_to_file_RLl(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RL_l_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

////////////////////
////////////////////
//RLCf
void select_load_item_RLCf(int input2) {
  switch (input2) {
    case 1:
      terminal_RLCf(out);
      break;
    case 2:
      file_RLCf(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLCf (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RLCf (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_f.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RLC_f.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_RLCf();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLCf(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLCf(array, n);
  }
  
}

int count_lines_RLCf() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RLC_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLCf(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RLC_f.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}



void write_array_to_file_RLCf(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_f_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}
////////////////////
////////////////////
//RLCf
void select_load_item_RLCc(int input2) {
  switch (input2) {
    case 1:
      terminal_RLCc(out);
      break;
    case 2:
      file_RLCc(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLCc (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RLCc (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_c.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RLC_c.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
  if(input3 == 9){
  int n = count_lines_RLCc();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLCc(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLCc(array, n);
  }
  
}

int count_lines_RLCc() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RLC_c.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLCc(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RLC_c.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}



void write_array_to_file_RLCc(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_c_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}
////////////////////
////////////////////
//RLCl
void select_load_item_RLCl(int input2) {
  switch (input2) {
    case 1:
      terminal_RLCl(out);
      break;
    case 2:
      file_RLCl(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_RLCl (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_RLCl (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_l.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to RLC_l.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
  if(input3 == 9){
  int n = count_lines_RLCl();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_RLCl(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_RLCl(array, n);
  }
  
}

int count_lines_RLCl() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("RLC_l.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_RLCl(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("RLC_l.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}



void write_array_to_file_RLCl(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("RLC_l_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}