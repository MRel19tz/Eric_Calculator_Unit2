#include <iostream>
#include <regex>
#include <cmath>
#include <thread>
#include "outputfile.h"
#include "loginout.h"
#include "user.h"
#include "rcfilter.h"
#include "rlfilter.h"
#include "rlcfilter.h"

void main_menu();
void print_main_menu();
void select_main_menu_item(int input);
void Read_me_main();
void go_back_to_main();
int get_main_input();

//color
void filter_menu();
int get_user_input();
void select_menu_item(int input);
void print_filter_menu();
void go_back_to_filter_menu();
bool is_integer(std::string num);
void menu_item_1();
void menu_item_2();
void menu_item_3();
void menu_item_4();
void Read_me_filter();
///////////////////////////
void filter_RC();
int get_RC_input();
void print_RC_menu();
void select_RC_item(int input);
void RC_frequency();
void RC_resistor();
void RC_capcitor();
void go_back_to_RC();
//////////////////////////
void filter_RL();
int get_RL_input();
void print_RL_menu();
void select_RL_item(int input);
void RL_frequency();
void RL_resistor();
void RL_inductance();
void go_back_to_RL();
///////////////////////////
void filter_RLC();
int get_RLC_input();
void print_RLC_menu();
void select_RLC_item(int input);
void RLC_frequency();
void RLC_inductance();
void RLC_capacitor();
void go_back_to_RLC();

void converter_menu();
void voltage_divider();
void colour_ring_menu();
void ohm_law_menu();
void slow_print(const std::string message, int milPerChar);
/////////////////////////////
extern char name[40];
extern char number[40];
extern User user;
double out;

using namespace std;

int main(int argc, char const *argv[]) {
  main_menu();
  system("color F4");
  return 0;
}

int get_main_input(){
  int input4;
  std::string input4_string;
  bool valid_input4 = false;
  int menu_items = 7;
  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input4_string;
    valid_input4 = is_integer(input4_string);
    // if input is not an integer, print an error message
    if (valid_input4 == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input4 = std::stof(input4_string);
    }
      if (input4 >= 1 && input4 <= menu_items) {
        valid_input4 = true;
      } else {
        std::cout << "😔 ";
        std::cout << "\033[1;40;31m Invalid menu item\033[1;40;37m\n";
      }
    } while (valid_input4 == false);
  return input4;
}


void main_menu() {
  print_main_menu();
  int input = get_main_input();
  select_main_menu_item(input);
}

void print_main_menu() {
  std::cout << "\n\033[45m-------- Main  Menu 😉 --------\033[40;37m\n";
  std::cout << "\033[45m                               \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   Read me first!🔍      \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   Filters               \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   Number System Page    \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   Voltage Divider       \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   Colour Code Resistor  \033[40;37m\n";
  std::cout << "\033[47;30m     6️⃣   Ohm's  Law            \033[40;37m\n";
  std::cout << "\033[47;30m     7️⃣   Quit     🪐           \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";

}

void select_main_menu_item(int input) {
  switch (input) {
    case 1:
      Read_me_main();
      break;
    case 2:
      filter_menu();
      break;
    case 3:
      converter_menu();
      break;
    case 4:
      voltage_divider();
      break;
    case 5:
      colour_ring_menu();
      break;
    case 6:
      ohm_law_menu();
      break;
    case 7:
      quit();
      break;       
    default:
      exit(1);
      break;
  }
}

void Read_me_main(){
  cout << "\n\033[41m------------------ Menu Guidance 😀 ------------------\033[40;37m\n";
  cout << "\033[41m                                                      \033[40;37m\n";
  cout << "\033[47;30m                                                      \033[40;37m\n";      
  cout << "\033[47;30m     😀 Welcome to use this menu!                     \033[40;37m\n";
  cout << "\033[47;30m     Designers: Fei Xie, Tianwen Zhao, Jin Qian       \033[40;37m\n"; 
  cout << "\033[47;30m     Design Date: 9 Dec 2021                          \033[40;37m\n"; 

  cout << "\033[47;30m                                                      \033[40;37m\n";

  cout << "\033[47;30m     We have five different choices and you can use   \033[40;37m\n"; 
  cout << "\033[47;30m   them as calculators. We have separate “Read Me”    \033[40;37m\n";
  cout << "\033[47;30m   section in every page to guide you.                \033[40;37m\n";

  cout << "\033[47;30m                                                      \033[40;37m\n";
      
  cout << "\033[47;30m     The five sections are Filter,Number System Page, \033[40;37m\n";
  cout << "\033[47;30m   Voltage Divider,Colour Code Resistor and Ohm’s Law.\033[40;37m\n";
  cout << "\033[47;30m   We design these sections to make an system related \033[40;37m\n";
  cout << "\033[47;30m   to electronics.                                    \033[40;37m\n";

  cout << "\033[47;30m                                                      \033[40;37m\n";
  cout << "\033[47;30m     Remember that you can not directly quit this     \033[40;37m\n";
  cout << "\033[47;30m system. Please choose “Quiting” button and grade our \033[40;37m\n";
  cout << "\033[47;30m system. 😆                                           \n"; 
  cout << "\033[47;30m                                                      \033[40;37m\n";

go_back_to_main();
}

void go_back_to_main() {
  std::string input;
  do {
    std::cout <<"\n\033[37m🌅";
    slow_print( "\033[37m Enter \033[31m'm'\033[37m or \033[31m'M'\033[37m to go back to main menu: ",60);
    std::cin >> input;
  } while (input != "m" && input != "M");
  main_menu();
}

void filter_menu() {
  print_filter_menu();
  int input = get_user_input();
  select_menu_item(input);
}

void select_menu_item(int input) {
  switch (input) {
    case 1:
      Read_me_filter();
      break;
    case 2:
      filter_RC();
      break;
    case 3:
      filter_RL();
      break;
    case 4:
      filter_RLC();
      break;
    case 5:
      main_menu();
      break;      
    default:
      exit(1);
      break;
  }
}

void print_filter_menu() {
  std::cout << "\n\033[44m---- Filter Select Page 😀 ----\033[40;37m\n";
  std::cout << "\033[44m                               \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   Read me first!🔍      \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   RC  filter            \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   RL  filter            \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   RLC filter            \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   Back to main menu     \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";

}

void go_back_to_filter() {
  std::string input;
  do {
    std::cout <<"\n\033[37m 💠";
    slow_print( "\033[37m Enter \033[31m'b'\033[37m or \033[31m'B'\033[37m to go back to filter menu: ",60);
    std::cin >> input;
  } while (input != "b" && input != "B");
  filter_menu();
}

//
//
//RC_filter pages

void Read_me_filter() {
   std::cout <<"\n\033[44m------------------------- Read me first ------------------------\033[40;37m\n";
  std::cout << "\033[44m                          🔴🟠🟡🟢🔵🟣                          \033[40;37m\n";
  std::cout << "\033[47;30m                                                                \033[40;37m\n";
  std::cout << "\033[47;30m 🟥 Welcome to filter calculator, where you can choose RC,      \033[40;37m\n";
  std::cout << "\033[47;30m    RL and RLC three different filter models to operate.        \033[40;37m\n";
  std::cout << "\033[47;30m 🟨 In various filters, you need to give any two parameters     \033[40;37m\n";
  std::cout << "\033[47;30m    to calculate the other parameter value by yourself.         \033[40;37m\n";
  std::cout << "\033[47;30m 🟩 Can choose to print the calculated values on the terminal   \033[40;37m\n";
  std::cout << "\033[47;30m    or txt file, and sort the data according to the needs.      \033[40;37m\n";
  std::cout << "\033[47;30m                                                                \033[40;37m\n";
  go_back_to_filter();
  system("color F4");
}

void filter_RC() {
  print_RC_menu();
  int input = get_user_input();
  select_RC_item(input);
}

void print_RC_menu() {
  std::cout << "\n\033[42m----------------------------- RC Filter🧮 ----------------------------\033[40;37m\n";
  std::cout << "\033[42m                                🐈💨💨                                \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";
  std::cout << "\033[47;30m                                             \033[40;37m";
  cout<<"\033[47;30m  ┏━━━━━━━━━━━━━━━━━━━┓  \033[40;37m\n";
  std::cout << "\033[47;30m    1️⃣   Calculate the cut-off frequency(Hz)  \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    2️⃣   Calculate the resistor value(Ω)      \033[40;37m";
  cout<<"\033[47;30m━━┻━━                ██  \033[40;37m\n";
  std::cout << "\033[47;30m    3️⃣   Calculate the capacitor value(F)     \033[40;37m";
  cout<<"\033[47;30m ━┳━                 ██  \033[40;37m\n";
  std::cout << "\033[47;30m    4️⃣   Back to filter page 📑               \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    5️⃣   Back to main page   📝               \033[40;37m";
  cout<<"\033[47;30m  ┗━━━━━━━━▊ ▊━━━━━━━━┛  \033[40;37m\n"; 
  std::cout << "\033[47;30m                                                \033[37;42m RC Filter Circuit \033[37;47m   \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";

}

int get_RC_input() {
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 4;

  do {
    slow_print( "\nSelect item",60);
    std::cout << "👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    // if input is not an integer, print an error message
    if (valid_input == false) {
      slow_print("Please enter an integer to select which component to calculate:\n",60);
    } else {  // if it is an int, check whether in range
      input = std::stoi(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔";
        slow_print("\033[31m Invalid menu item\033[1;40;37m\n",60);
        valid_input = false;
      }
    }
  } while (valid_input == false);

  return input;
}

void select_RC_item(int input) {
  switch (input) {
    case 1:
      RC_frequency();
      break;
    case 2:
      RC_resistor();
      break;
    case 3:
      RC_capcitor();
      break;
    case 4:
      filter_menu();
      break;
    case 5:
      main_menu();
      break;
    default:
      exit(1);
      break;
  }
}

void go_back_to_RC() {
  std::string input;
  do {
    std::cout << "\n✨";
    slow_print( "Please enter 'c' or 'C' to go back to RC menu: ",60);
    std::cin >> input;
  } while (input != "c" && input != "C");
  filter_RC();
}

void RC_frequency() {
    double rv;
    double cv;
    double fv;
    double PI = 3.14;
  std::cout << "\n>> RC_frequency\n";
  slow_print("\nPlease provide the value of resistor: ",60);
  std::cin  >> rv;
  slow_print("\nPlease provide the value of capcitor: ",60);
  std::cin  >> cv;
  fv = 1/(2*PI*rv*cv);
  out = fv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RCf(input2);
  // you can call a function from here that handles menu 2
    go_back_to_RC();
}

void RC_resistor() {
    double rv;
    double cv;
    double fv;
    double PI = 3.14;
    std::cout << "\n>> RC_resistor\n";
    slow_print("\nPlease provide the value of cut-off frequency: ",60);
    std::cin  >> fv;
    slow_print("\nPlease provide the value of capcitor: ",60);
    std::cin  >> cv;
    rv = 1/(2*PI*fv*cv);
    out = rv;
    int input2;
    choose_output_menu();
    input2 = get_input2();
    select_load_item_RCr(input2);
  // you can call a function from here that handles menu 2
    go_back_to_RC();
}

void RC_capcitor() {
    double rv;
    double cv;
    double fv;
    double PI = 3.14;
   std::cout << "\n>> RC_capacitor\n";
  slow_print("\nPlease provide the value of resistor: ",60);
  std::cin  >> rv;
  slow_print("\nPlease provide the value of cut-off: ",60);
  std::cin  >> fv;
  cv = 1/(2*PI*rv*fv);
  out = cv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RCc(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RC();
}

////////
////////
//RL Filter
void filter_RL() {
  print_RL_menu();
  int input = get_user_input();
  select_RL_item(input);
}

void print_RL_menu() {
  std::cout << "\n\033[41m----------------------------- RL Filter🧮 ----------------------------\033[40;37m\n";
  std::cout << "\033[41m                                🦕💨💨                                \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";
  std::cout << "\033[47;30m                                             \033[40;37m";
  cout<<"\033[47;30m  ┏━━━━━━━━━━━━━━━━━━━┓  \033[40;37m\n";
  std::cout << "\033[47;30m    1️⃣   Calculate the cut-off frequency(Hz)  \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    2️⃣   Calculate the resistor value(Ω)      \033[40;37m";
  cout<<"\033[47;30m━━┻━━                ██  \033[40;37m\n";
  std::cout << "\033[47;30m    3️⃣   Calculate the inductance value(F)    \033[40;37m";
  cout<<"\033[47;30m ━┳━                 ██  \033[40;37m\n";
  std::cout << "\033[47;30m    4️⃣   Back to filter page 📑               \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    5️⃣   Back to main page   📝               \033[40;37m";
  cout<<"\033[47;30m  ┗━━━━━━━━∧∧∧∧━━━━━━━┛  \033[40;37m\n"; 
  std::cout << "\033[47;30m                                                \033[37;41m RL Filter Circuit \033[37;47m   \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";

}

int get_RL_input() {
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 4;

  do {
    slow_print( "\nSelect item",60);
    std::cout << "👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    // if input is not an integer, print an error message
    if (valid_input == false) {
      std::cout << "🔸";
      slow_print( "Please enter an integer to select which component to calculate:\n",60);
    } else {  // if it is an int, check whether in range
      input = std::stoi(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔";
        slow_print("\033[31mInvalid menu item\033[1;40;37m\n",60);
        valid_input = false;
      }
    }
  } while (valid_input == false);

  return input;
}

void select_RL_item(int input) {
  switch (input) {
    case 1:
      RL_frequency();
      break;
    case 2:
      RL_resistor();
      break;
    case 3:
      RL_inductance();
      break;
    case 4:
      filter_menu();
      break;
    case 5:
      main_menu();
      break; 
    default:
      exit(1);
      break;
  }
}

void go_back_to_RL() {
  std::string input;
  do {
    std::cout << "\n✨";
    slow_print( "Please enter 'l' or 'L' to go back to RL menu: ",60);
    std::cin >> input;
  } while (input != "l" && input != "L");
  filter_RL();
}

void RL_frequency() {
    double rv;
    double lv;
    double fv;
    double PI = 3.14;
  std::cout << "\n>> RL_frequency:\n";
  slow_print( "\nPlease provide the value of resistor: ",60);
  std::cin  >> rv;
  slow_print( "\nPlease provide the value of inductance: ",60);
  std::cin  >> lv;
  fv = rv/(2*PI*lv);
  out = fv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLf(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RL();
}

void RL_resistor() {
    double rv;
    double lv;
    double fv;
    double PI = 3.14;
  std::cout << "\n>> RL_resistor\n";
  slow_print( "\nPlease provide the value of cut-off frequency: ",60);
  std::cin  >> fv;
  slow_print( "\nPlease provide the value of inductance: ",60);
  std::cin  >> lv;
  rv = 2*PI*fv*lv;
  out = rv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLr(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RL();
}

void RL_inductance() {
    double rv;
    double lv;
    double fv;
    double PI = 3.14;
   std::cout << "\n>> RL_inductance\n";
  slow_print("\nPlease provide the value of resistor: ",60);
  std::cin  >> rv;
  slow_print("\nPlease provide the value of cut-off frequency: ",60);
  std::cin  >> fv;
  lv = rv/(2*PI*fv);
  out = lv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLl(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RL();
}

/////////////////////
/////////////////////
//RLC
void filter_RLC() {
  print_RLC_menu();
  int input = get_user_input();
  select_RLC_item(input);
}

void print_RLC_menu() {
  std::cout << "\n\033[45m----------------------------- RLC Filter🧮----------------------------\033[40;37m\n";
  std::cout << "\033[45m                                🐳💨💨                                \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";
  std::cout << "\033[47;30m                                             \033[40;37m";
  cout<<"\033[47;30m  ┏━━━━━━━━▊ ▊━━━━━━━━┓  \033[40;37m\n";
  std::cout << "\033[47;30m    1️⃣   Calculate the resonant frequency(Hz) \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    2️⃣   Calculate the capacitor value(Ω)     \033[40;37m";
  cout<<"\033[47;30m━━┻━━                ██  \033[40;37m\n";
  std::cout << "\033[47;30m    3️⃣   Calculate the inductance value(F)    \033[40;37m";
  cout<<"\033[47;30m ━┳━                 ██  \033[40;37m\n";
  std::cout << "\033[47;30m    4️⃣   Back to filter page 📑               \033[40;37m";
  cout<<"\033[47;30m  ┃                   ┃  \033[40;37m\n";
  std::cout << "\033[47;30m    5️⃣   Back to main page   📝               \033[40;37m";
  cout<<"\033[47;30m  ┗━━━━━━━━∧∧∧∧━━━━━━━┛  \033[40;37m\n"; 
  std::cout << "\033[47;30m                                                \033[37;45m RLC Filter Circuit \033[37;47m  \033[40;37m\n";
  std::cout << "\033[47;30m                                                                      \033[40;37m\n";

}

int get_RLC_input() {
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 6;

  do {
    slow_print( "\nSelect item",60);
    std::cout << "👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    // if input is not an integer, print an error message
    if (valid_input == false) {
      std::cout << "\n🔸";
      slow_print( "Please enter an integer to select which component to calculate:\n",60);
    } else {  // if it is an int, check whether in range
      input = std::stoi(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔";
        slow_print("\033[31m Invalid menu item\033[1;40;37m\n",60);
        valid_input = false;
      }
    }
  } while (valid_input == false);

  return input;
}

void select_RLC_item(int input) {
  switch (input) {
    case 1:
      RLC_frequency();
      break;
    case 2:
      RLC_capacitor();
      break;
    case 3:
      RLC_inductance();
      break;
    case 4:
      filter_menu();
      break;
    case 5:
      main_menu();
      break;
    default:
      exit(1);
      break;
  }
}

void go_back_to_RLC() {
  std::string input;
  do {
    std::cout << "\n✨";
    slow_print( "Please enter 'rlc' or 'RLC' to go back to RLC menu: ",60);
    std::cin >> input;
  } while (input != "rlc" && input != "RLC");
  filter_RLC();
}

void RLC_frequency() {
    double lv;
    double fv;
    double cv;
    double PI = 3.14;
   std::cout << "\n>> RLC_frequency\n";
  slow_print("\nPlease provide the value of capacitor: ",60);
  std::cin  >> cv;
  slow_print("\nPlease provide the value of inductance: ",60);
  std::cin  >> lv;
  fv = 1/(2*PI*sqrt(lv*cv));
  out = fv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLCf(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RLC();
}

void RLC_inductance() {
    double lv;
    double fv;
    double cv;
    double PI = 3.14;
  std::cout << "\n>> RLC_inductance\n";
  slow_print("\nPlease provide the value of capacitor: ",60);
  std::cin  >> cv;
  slow_print("\nPlease provide the value of resonant frequency: ",60);
  std::cin  >> fv;
  lv = 1/(2*PI*fv*2*PI*fv*cv);
  out = lv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLCl(input2);

  // you can call a function from here that handles menu 2
  go_back_to_RLC();
}

void RLC_capacitor() {
    double lv;
    double fv;
    double cv;
    double PI = 3.14;
  std::cout << "\n>> RLC_capacitor\n";
  slow_print("\nPlease provide the value of cut-off frequency: ",60);
  std::cin  >> fv;
  slow_print( "\nPlease provide the value of inductance: ",60);
  std::cin  >> lv;
  cv = 1/(2*PI*fv*2*PI*fv*lv);
  out = cv;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_load_item_RLCc(input2);
  // you can call a function from here that handles menu 2
  go_back_to_RLC();
}