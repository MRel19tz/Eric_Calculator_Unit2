#ifndef RLCFILTER_H
#define RLCFILTER_H
#include <string>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>

class RLCFilter
{
public:
    RLCFilter();
    void setOption(int option);
    void setCutoff(double cutoff);
    void setCapacitor(double resistor);
    void setInductance(double capacitor);
    double calCutoff();
    double calCapacitor();
    double calInductance();
    double setOut();
    std::string setFilename();
    std::string setOutFilename();
    void output(int outOption);
    void terminal(double out);
    void file(double out);
    int coutLines(std::string filename);
    void readIntoArray(double array[], int n, std::string filename);
    void writeArrayToFile(double array[], int n, std::string outFilename);

private:
    double m_cutoff;
    double m_capacitor;
    double m_inductance;
    int m_option;
    double PI;
};

#endif // RLCFILTER_H
