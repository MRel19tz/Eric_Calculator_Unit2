#ifndef OUTPUTFILE_H
#define OUTPUTFILE_H

#include <string>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <thread>

extern double out;

void main_menu();
void print_main_menu();
void select_main_menu_item(int input);
void Read_me_main();

void filter_menu();


int get_user_input();


void select_menu_item(int input);
void print_filter_menu();
void go_back_to_filter_menu();
bool is_integer(std::string num);


void filter_RC();
int get_RC_input();
void print_RC_menu();
void select_RC_item(int input);
void RC_frequency();
void RC_resistor();
void RC_capcitor();
void go_back_to_RC();

void filter_RL();
int get_RL_input();
void print_RL_menu();
void select_RL_item(int input);
void RL_frequency();
void RL_resistor();
void RL_inductance();
void go_back_to_RL();
///////////////////////////
void filter_RLC();
int get_RLC_input();
void print_RLC_menu();
void select_RLC_item(int input);
void RLC_frequency();
void RLC_inductance();
void RLC_capacitor();
void go_back_to_RLC();


extern double out;
void choose_output_menu();
int get_input2();
void order_array(double array[], int n);

//RC_f
void select_load_item_RCf(int input2);
int count_lines_RCf();
void read_into_array_RCf(double array[], int n);
void write_array_to_file_RCf(double array[], int n);

//RC_r
void select_load_item_RCr(int input2);
int count_lines_RCr();
void read_into_array_RCr(double array[], int n);
void write_array_to_file_RCr(double array[], int n);

//RC_c
void select_load_item_RCc(int input2);
int count_lines_RCc();
void read_into_array_RCc(double array[], int n);
void write_array_to_file_RCc(double array[], int n);

//RL_f
void select_load_item_RLf(int input2);
int count_lines_RLf();
void read_into_array_RLf(double array[], int n);
void write_array_to_file_RLf(double array[], int n);

//RL_r
void select_load_item_RLr(int input2);
int count_lines_RLr();
void read_into_array_RLr(double array[], int n);
void write_array_to_file_RLr(double array[], int n);

//RL_l
void select_load_item_RLl(int input2);
int count_lines_RLl();
void read_into_array_RLl(double array[], int n);
void write_array_to_file_RLl(double array[], int n);

//RLC_f
void select_load_item_RLCf(int input2);
int count_lines_RLCf();
void read_into_array_RLCf(double array[], int n);
void write_array_to_file_RLCf(double array[], int n);

//RLC_c
void select_load_item_RLCc(int input2);
int count_lines_RLCc();
void read_into_array_RLCc(double array[], int n);
void write_array_to_file_RLCc(double array[], int n);

//RLC_l
void select_load_item_RLCl(int input2);
int count_lines_RLCl();
void read_into_array_RLCl(double array[], int n);
void write_array_to_file_RLCl(double array[], int n);
void slow_print(const std::string message, int milPerChar);



void select_voltage_divider_item(int input);
void print_voltage_divider_menu();
void voltage_divider_menu();
void go_back_to_voltage_divider();

void choose_output_menu();
int get_input();
void select_vin_item(int input, double out);
void select_vout_item(int input, double out);
void select_r1_item(int input, double out);
void select_r2_item(int input, double out);

int count_lines_vin();
void read_into_array_vin(double array[], int n);
void write_array_to_file_vin(double array[], int n);
int count_lines_vout();
void read_into_array_vout(double array[], int n);
void write_array_to_file_vout(double array[], int n);
int count_lines_r1();
void read_into_array_r1(double array[], int n);
void write_array_to_file_r1(double array[], int n);
int count_lines_r2();
void read_into_array_r2(double array[], int n);
void write_array_to_file_r2(double array[], int n);

void main_menu_voltagedivider();



#endif