#include "user.h"
#include<iostream>
#include <fstream>
using namespace std;

void User::getname(){
	std::cout << "Thank you for your use. Before you leave, we want to record your comments. Please allow us to know your name:\n ";
  memset(name, '\0', 40);
  memset(number, '\0', 40);
  cin >> name;
  cout << name ;
  std::cout << ", nice to meet you. Please provide your student ID number:\n ";
  cin >> number;
}

void User::getv( int input_quit ){
switch (input_quit) {
  memset(evaluation, '\0', 40);
    case 1:
      strcpy(evaluation, "Excellent");
      break;
    case 2:
      strcpy(evaluation, "Good");
      break;
    case 3:
      strcpy(evaluation, "Medium");
      break;
    case 4:
      strcpy(evaluation, "Ecumenic");
      break;
    case 5:
      strcpy(evaluation, "Bad");
      break;
    default:
      exit(1);
      break;
  }
}

void User::toString(){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("user.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // print to the file and then close the stream
  output<<"//////////////////////////////"<<endl;
	output<<"Name:"<<name<<endl;
	output<<"ID number:"<<number<<endl;
	output<<"Evaluation:"<<evaluation<<endl;
  output.close();
}