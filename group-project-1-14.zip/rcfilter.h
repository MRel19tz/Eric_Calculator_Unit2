#ifndef RCFILTER_H
#define RCFILTER_H

#include <string>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>

class RCFilter
{
public:
    RCFilter();
    void setOption(int option);
    void setCutoff(double cutoff);
    void setResistor(double resistor);
    void setCapacitor(double capacitor);
    double calCutoff();
    double calResistor();
    double calCapacitor();
    double setOut();
    std::string setFilename();
    std::string setOutFilename();
    void output(int outOption);
    void terminal(double out);
    void file(double out);
    int coutLines(std::string filename);
    void readIntoArray(double array[], int n, std::string filename);
    void writeArrayToFile(double array[], int n, std::string outFilename);

private:
    double m_cutoff;
    double m_resistor;
    double m_capacitor;
    int m_option;
    double PI;
};

#endif // RCFILTER_H
