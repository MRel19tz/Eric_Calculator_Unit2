#ifndef RLFILTER_H
#define RLFILTER_H

#include <string>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>

class RLFilter
{
public:
    RLFilter();
    void setOption(int option);
    void setCutoff(double cutoff);
    void setResistor(double resistor);
    void setInductance(double capacitor);
    double calCutoff();
    double calResistor();
    double calInductance();
    double setOut();
    std::string setFilename();
    std::string setOutFilename();
    void output(int outOption);
    void terminal(double out);
    void file(double out);
    int coutLines(std::string filename);
    void readIntoArray(double array[], int n, std::string filename);
    void writeArrayToFile(double array[], int n, std::string outFilename);

private:
    double m_cutoff;
    double m_resistor;
    double m_inductance;
    int m_option;
    double PI;
};

#endif // RLFILTER_H
