#include <thread>
#include <iostream>
#include <regex>
using namespace std;
#include "outputfile.h"
#define N 50

void print_ohm_law_menu();
int get_input_ohm_law();
void select_ohm_law_item(int input);
void go_back_to_ohm_law();
void read_me_ohm_law();
void ohm_law_V();
void ohm_law_I();
void ohm_law_R();
//////V
void select_ohm_law_V_item(int input,double out);
void terminal_ohm_law_V(double out);
void file_ohm_law_V (double out);
//////R
void select_ohm_law_R_item(int input,double out);
void terminal_ohm_law_R(double out);
void file_ohm_law_R (double out);
//////I
void select_ohm_law_I_item(int input,double out);
void terminal_ohm_law_I(double out);
void file_ohm_law_I (double out);


void ohm_law_menu(){
  print_ohm_law_menu();
  int input = get_input_ohm_law();
  select_ohm_law_item(input);
}

int get_input_ohm_law(){
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 5;
  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    // if input is not an integer, print an error message
    if (valid_input == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input = std::stof(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔\033[1;40;31m Invalid menu item\033[1;40;37m\n";
        valid_input = false;
      }
    }
  } while (valid_input == false);
  return input;
}

void print_ohm_law_menu(){
    std::cout << "\n\033[44m----- Omh's Law Page 😀 -----\033[40;37m\n";
  std::cout << "\033[44m                             \033[40;37m\n";
  std::cout << "\033[47;30m                             \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   Read me first!🔍    \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   V is unknown        \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   R is unknown        \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   I is unknown        \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   Back to main menu   \033[40;37m\n";
  std::cout << "\033[47;30m                             \033[40;37m\n";
}

void select_ohm_law_item(int input){
  switch(input)
  {
  case 1: 
    read_me_ohm_law();
    break;
  case 2: 
    ohm_law_V();
    break;
  case 3: 
    ohm_law_I();
    break;
  case 4: 
    ohm_law_R();
    break;
  case 5: 
    main_menu();
    break;
  default : 
    exit(1);
    break;
  }
}

void go_back_to_ohm_law() {
  std::string input;
  do {
    std::cout << "\n💫";
    slow_print( "Please enter 'ohm' or 'OHM' to go back to Ohm's Law menu: ",60);
    std::cin >> input;
  } while (input != "OHM" && input != "ohm");
  ohm_law_menu();
}

void read_me_ohm_law()
{
   std::cout <<"\n\033[44m------------------------ Read me first -----------------------\033[40;37m\n";
  std::cout << "\033[44m                         🔴🟠🟡🟢🔵🟣                         \033[40;37m\n";
  std::cout << "\033[47;30m                                                              \033[40;37m\n";
  std::cout << "\033[47;30m 🟥 Welcome to Ohm's law calculator, where you can choose to, \033[40;37m\n";
  std::cout << "\033[47;30m    calculate voltage, current and resistance.                \033[40;37m\n";
  std::cout << "\033[47;30m 🟨 In various circuits, you need to give any two parameters  \033[40;37m\n";
  std::cout << "\033[47;30m    to calculate the other parameter value by yourself.       \033[40;37m\n";
  std::cout << "\033[47;30m 🟩 Can choose to print the calculated values on the terminal \033[40;37m\n";
  std::cout << "\033[47;30m    or txt file, and sort the data according to the needs.    \033[40;37m\n";
  std::cout << "\033[47;30m                                                              \033[40;37m\n";
  go_back_to_ohm_law();
}

void select_ohm_law_V_item(int input,double out) {
  switch (input) {
    case 1:
      terminal_ohm_law_V(out);
      break;
    case 2:
      file_ohm_law_V(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_ohm_law_V (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_ohm_law_V (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Ohm's law (voltage).txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to Ohm's law (voltage).txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_vin();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_vin(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_vin(array, n);
  }
}

void ohm_law_V()
{
    double vin;
    double R;
    double I;
    slow_print("Please input the resistance: ",60);
    cin >> R;
    slow_print("Please input the current: ",60);
    cin >> I;
    vin = R*I;
    double out = vin;
    int input;
    choose_output_menu();
    input = get_input2();
    select_ohm_law_V_item(input,out);
    go_back_to_ohm_law();
}

void select_ohm_law_R_item(int input,double out) {
  switch (input) {
    case 1:
      terminal_ohm_law_R(out);
      break;
    case 2:
      file_ohm_law_R(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_ohm_law_R(double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_ohm_law_R (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Ohm's law (resistance).txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to Ohm's law (resistance).txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_vin();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_vin(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_vin(array, n);
  }
}

void ohm_law_R()
{
    double vin;
    double V;
    double I;
    slow_print("Please input the voltage: ",60);
    cin >> V;
    slow_print("Please input the current: ",60);
    cin >> I;
    vin = V/I;
    double out = vin;
    int input;
    choose_output_menu();
    input = get_input2();
    select_ohm_law_R_item(input,out);
    go_back_to_ohm_law();
}

void select_ohm_law_I_item(int input,double out) {
  switch (input) {
    case 1:
      terminal_ohm_law_I(out);
      break;
    case 2:
      file_ohm_law_I(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_ohm_law_I(double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_ohm_law_I(double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Ohm's law (current).txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to Ohm's law (current).txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_vin();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_vin(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_vin(array, n);
  }
}

void ohm_law_I()
{
    double vin;
    double V;
    double R;
    slow_print("Please input the voltage: ",60);
    cin >> V;
    slow_print("Please input the resistance: ",60);
    cin >> R;
    vin = V/R;
    double out = vin;
    int input;
    choose_output_menu();
    input = get_input2();
    select_ohm_law_I_item(input,out);
    go_back_to_ohm_law();
}