#ifndef USER_H
#define USER_H
#include <string>
#include<iostream>
#include<string.h>
using namespace std;

class User {
private:
	char name[40];
	char evaluation[40];
	char number[40];
public:
	void getname();
  void getv(int input_quit);
	void toString();
};



#endif