#include "rcfilter.h"

RCFilter::RCFilter()
{
    PI = 3.14159;
}

void RCFilter::setOption(int option){
    m_option = option;
}

void RCFilter::setCutoff(double cutoff){
    m_cutoff = cutoff;
}

void RCFilter::setResistor(double resistor){
    m_resistor = resistor;
}

void RCFilter::setCapacitor(double capacitor){
    m_capacitor = capacitor;
}

double RCFilter::calCutoff(){
    m_cutoff = 1/(2 * PI * m_resistor * m_capacitor);
    return m_cutoff;
}

double RCFilter::calResistor(){
    m_resistor = 1 / (2 * m_cutoff * m_capacitor);
    return m_resistor;
}

double RCFilter::calCapacitor(){
    m_capacitor = 1 / (2 * m_cutoff * m_resistor);
    return m_capacitor;
}


double RCFilter::setOut(){
    double out;
    switch(m_option){
        case 1:
            out = m_cutoff;
            break;
        case 2:
            out = m_resistor;
            break;
        case 3:
            out = m_capacitor;
            break;
    }
    return out;
}

std::string RCFilter::setFilename(){
    std::string filename;
    switch(m_option){
        case 1:
            filename = "RC_f.txt";
            break;
        case 2:
            filename = "RC_r.txt";
            break;
        case 3:
            filename = "RC_c.txt";
            break;
    }
    return filename;
}

std::string RCFilter::setOutFilename(){
    std::string outFilename;
    switch(m_option){
        case 1:
            outFilename = "RC_f_ordered.txt";
            break;
        case 2:
            outFilename = "RC_r_ordered.txt";
            break;
        case 3:
            outFilename = "RC_c_ordered.txt";
            break;
    }
    return outFilename;
}

void RCFilter::output(int outOption){
    double out;
    out = setOut();
    switch(outOption){
        case 1:
            terminal(out);
            break;
        case 2:
            file(out);
            break;
        default:
            exit(1);
            break;
    }
}

void RCFilter::terminal(double out){
    std::cout <<"🌸The value of you want is: " << out <<"Hz" <<std::endl;
}

void RCFilter::file(double out){
    std::string filename;
    filename = setFilename();
    std::ofstream output;
    // use it to open a file named 'output.txt'
    output.open(filename,std::fstream::app);
    // check if the file is not open
    if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
    }
    // print to the file and then close the stream
    output << out << std::endl;
    output.close();
    std::cout <<"Congratulations！The value you need is loaded to"<< filename << "Please check it~💕\n";
    std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
    int input3;
    std::cin >> input3;
    if(input3 == 9){
    int n = coutLines(filename);
    double *array = new double[n];
    // read the random numbers into the array
    readIntoArray(array, n, filename);
    // order the values in the array
    std::sort(array, array + n);  // ascending
    // then write ordered values to file 'ordered.txt'
    std::string outFilename;
    outFilename = setOutFilename();
    writeArrayToFile(array, n, outFilename);
    }
}

int RCFilter::coutLines(std::string filename){
    // create an input file stream
    std::ifstream input;
    // use it to open a file named 'random.txt'
    input.open(filename);
    // check if the file is not open
    if (!input.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error! No input file found!\n";
        exit(1);
    }
    int n = 0;
    std::string dummy;
    // keep reading lines in file until no lines left to read
    // read into dummy string and increment count
    while (getline(input, dummy)) {
        n++;
    }
    input.close();
    return n;
}

void RCFilter::readIntoArray(double array[], int n, std::string filename){
    // create an input file stream
    std::ifstream input;
    // use it to open a file named 'MOCK_DATA.csv'
    input.open(filename);
    // check if the file is not open
    if (!input.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error! No input file found!\n";
        exit(1);
    }
    // loop through each line in file
    std::string dummy;
    for (int i = 0; i < n; i++) {
        input >> dummy;
        // read in value, covert to int and write to array
        array[i] = std::stof(dummy);
    }
    input.close();
}

void RCFilter::writeArrayToFile(double array[], int n, std::string outFilename){
    // create an output file stream
    std::ofstream output;
    // use it to open a file named 'output.txt'
    output.open(outFilename);
    // check if the file is not open
    if (!output.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error creating file!\n";
        exit(1);
    }
    // loop through and prdouble array
    for (int i = 0; i < n; i++) {
        output << array[i] << std::endl;
    }
    output.close();
}
