#include<stdio.h>
#include <thread>
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include <cmath>
#include<bitset>
#include"outputfile.h"

using namespace std;

#define N 50
std::string s1;
long int number,i=0;


void converter_menu();
void print_converter_menu();
int get_user_input();
bool is_integer(std::string num);
void select_converter_menu_item(int input);
void go_back_to_converter();
void read_me_converter();
void binarysys();
void octalsys();
void hex();
void slow_print(const std::string message, int milPerChar);

bool is_integer(std::string num);
void select_b_item(int input2, long int number);
void select_o_item(int input2, long int number);
void select_h_item(int input2, long int number);
void terminal_b(long int number);
void file_b(long int number);
void terminal_o(long int number);
void file_o(long int number);
void terminal_h(long int number);
void file_h(long int number);

void slow_print(const string message, int milPerChar = 60) {
  for (const char c : message) {
    cout << c << flush;
    this_thread::sleep_for(chrono::milliseconds(milPerChar));
  }//end of delay for
}

void converter_menu(){
  print_converter_menu();
  int input = get_user_input();
  select_converter_menu_item(input);
}

void print_converter_menu(){
  std::cout << "\n\033[42m------- Number System Page🧮 ------\033[40;37m\n";
  std::cout << "\033[42m                                   \033[40;37m\n";
  std::cout << "\033[47;30m                                   \033[40;37m\n";
  std::cout << "\033[47;30m    1️⃣   Read me first              \033[40;37m\n";
  std::cout << "\033[47;30m    2️⃣   Decimal to Binary          \033[40;37m\n";
  std::cout << "\033[47;30m    3️⃣   Decimal to Octanary        \033[40;37m\n";
  std::cout << "\033[47;30m    4️⃣   Decimal to Hexadeciaml     \033[40;37m\n";
  std::cout << "\033[47;30m    5️⃣   Back to main page  📝      \033[40;37m\n"; 
  std::cout << "\033[47;30m                                   \033[40;37m\n";
}

int get_user_input() {
  int input;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 6;

  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    
    // if input is not an integer, print an error message
    if (valid_input == false) {
      slow_print( "Please enter an integer to select which component to calculate:\n",60);
    } else {  // if it is an int, check whether in range
      input = std::stoi(input_string);  // convert to int
      if (input >= 1 && input <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔";
        slow_print("\033[31m Invalid menu item\033[1;40;37m\n",60);
        valid_input = false;
      }
    }
  } while (valid_input == false);

  return input;
}

bool is_integer(std::string num) {
  return std::regex_match(num, std::regex("[+-]?[0-9]+"));
}

void select_converter_menu_item(int input) {
  switch(input){
    case 1: 
      read_me_converter();
      break;
    case 2: 
      binarysys();
      break;
    case 3: 
      octalsys();
      break;
    case 4: 
      hex();
      break;
    case 5: 
      main_menu();
      break;
    default : 
      slow_print( "Please enter an integer number between 1 and 4!",60);
  }
}

void go_back_to_converter() {
  std::string input;
  do {
    std::cout <<"\n\033[37m🧊";
    slow_print( "\033[37m Enter \033[31m'b'\033[37m or \033[31m'B'\033[37m to go back to converter menu: ",60);
    std::cin >> input;
  } while (input != "b" && input != "B");
  converter_menu();
}

void read_me_converter()
{
   std::cout <<"\n\033[44m-------------------- Read me first -------------------\033[40;37m\n";
   std::cout << "\033[44m                     🔴🟠🟡🟢🔵🟣                     \033[40;37m\n";
   std::cout << "\033[47;30m                                                      \033[40;37m\n";
   std::cout << "\033[47;30m 🟥 Welcome to number converter, where you can choose \033[40;37m\n";
   std::cout << "\033[47;30m    binary,octanary and hexadeciaml three different   \033[40;37m\n";
   std::cout << "\033[47;30m    converter models to operate.                      \033[40;37m\n";
   std::cout << "\033[47;30m 🟨 In various converters, you need to input one      \033[40;37m\n";
   std::cout << "\033[47;30m    number to convert.                                \033[40;37m\n";
   std::cout << "\033[47;30m 🟩 Can choose to print the calculated values on the  \033[40;37m\n";
   std::cout << "\033[47;30m    terminal or txt file, and sort the data according \033[40;37m\n";
   std::cout << "\033[47;30m    to the needs.                                     \033[40;37m\n";
   std::cout << "\033[47;30m                                                      \033[40;37m\n";
   go_back_to_converter();
   system("color F4");

}

void binarysys()
{
  long int number,i=0;
  int arr[N];
  slow_print("Please input the number:");
  scanf("%ld",&number);
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_b_item(input2,number);
  printf("\n");
}

void octalsys()
{
  long int number,i=0;
  int arr[N];
  slow_print("Please input the number:");
  cin>>number;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_o_item(input2,number);
}

void hex()
{
  long int number,i=0;
  int arr[N];
  slow_print("Please input the number:");
  cin>>number;
  int input2;
  choose_output_menu();
  input2 = get_input2();
  select_h_item(input2,number);
}

/////b
void select_b_item(int input2, long int number) {
  switch (input2) {
    case 1:
      terminal_b(number);
      break;
    case 2:
      file_b(number);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_b (long int number ){
  std::cout <<"The value of you want is " <<bitset<8>(number)<<std::endl;
  go_back_to_converter();
}

void file_b (long int number){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Converter_binary.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output <<bitset<8>(number)<< std::endl;
  go_back_to_converter();
}

/////o
void select_o_item(int input2, long int number) {
  switch (input2) {
    case 1:
      terminal_o(number);
      break;
    case 2:
      file_o(number);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_o (long int number ){
  std::cout <<"The value of you want is " <<std::oct<<number<<std::endl;
  go_back_to_converter();
}

void file_o (long int number){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Converter_Octanary.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output <<std::oct<<number<< std::endl;
  go_back_to_converter();
}
/////h
void select_h_item(int input2, long int number) {
  switch (input2) {
    case 1:
      terminal_h(number);
      break;
    case 2:
      file_h(number);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_h (long int number ){
  std::cout <<"The value of you want is " <<std::hex<<number<<std::endl;
  go_back_to_converter();
}

void file_h (long int number){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Converter_Hex.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output <<std::hex<<number<< std::endl;
  go_back_to_converter();
}

