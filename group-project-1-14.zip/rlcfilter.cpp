#include "rlcfilter.h"

RLCFilter::RLCFilter()
{
    PI = 3.14159;
}


void RLCFilter::setOption(int option){
    m_option = option;
}

void RLCFilter::setCutoff(double cutoff){
    m_cutoff = cutoff;
}

void RLCFilter::setCapacitor(double capacitor){
    m_capacitor = capacitor;
}

void RLCFilter::setInductance(double inductance){
    m_inductance = inductance;
}

double RLCFilter::calCutoff(){
    m_cutoff = 1/(2 * PI * sqrt(m_inductance * m_capacitor));
    return m_cutoff;
}

double RLCFilter::calInductance(){
    m_inductance = 1 / (2 * PI * m_cutoff * 2 * PI * m_cutoff * m_capacitor);
    return m_inductance;
}

double RLCFilter::calCapacitor(){
    m_capacitor = 1 / (2 * PI * m_cutoff * 2 * PI * m_cutoff * m_inductance);
    return m_capacitor;
}


double RLCFilter::setOut(){
    double out;
    switch(m_option){
        case 1:
            out = m_cutoff;
            break;
        case 2:
            out = m_capacitor;
            break;
        case 3:
            out = m_inductance;
            break;
    }
    return out;
}

std::string RLCFilter::setFilename(){
    std::string filename;
    switch(m_option){
        case 1:
            filename = "RLC_f.txt";
            break;
        case 2:
            filename = "RLC_c.txt";
            break;
        case 3:
            filename = "RLC_l.txt";
            break;
    }
    return filename;
}

std::string RLCFilter::setOutFilename(){
    std::string outFilename;
    switch(m_option){
        case 1:
            outFilename = "RLC_f_ordered.txt";
            break;
        case 2:
            outFilename = "RLC_c_ordered.txt";
            break;
        case 3:
            outFilename = "RLC_l_ordered.txt";
            break;
    }
    return outFilename;
}

void RLCFilter::output(int outOption){
    double out;
    out = setOut();
    switch(outOption){
        case 1:
            terminal(out);
            break;
        case 2:
            file(out);
            break;
        default:
            exit(1);
            break;
    }
}

void RLCFilter::terminal(double out){
    std::cout <<"🌸The value of you want is: " << out <<"Hz" <<std::endl;
}

void RLCFilter::file(double out){
    std::string filename;
    filename = setFilename();
    std::ofstream output;
    // use it to open a file named 'output.txt'
    output.open(filename,std::fstream::app);
    // check if the file is not open
    if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
    }
    // print to the file and then close the stream
    output << out << std::endl;
    output.close();
    std::cout <<"Congratulations！The value you need is loaded to"<< filename << "Please check it~💕\n";
    std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
    int input3;
    std::cin >> input3;
    if(input3 == 9){
    int n = coutLines(filename);
    double *array = new double[n];
    // read the random numbers into the array
    readIntoArray(array, n, filename);
    // order the values in the array
    std::sort(array, array + n);  // ascending
    // then write ordered values to file 'ordered.txt'
    std::string outFilename;
    outFilename = setOutFilename();
    writeArrayToFile(array, n, outFilename);
    }
}

int RLCFilter::coutLines(std::string filename){
    // create an input file stream
    std::ifstream input;
    // use it to open a file named 'random.txt'
    input.open(filename);
    // check if the file is not open
    if (!input.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error! No input file found!\n";
        exit(1);
    }
    int n = 0;
    std::string dummy;
    // keep reading lines in file until no lines left to read
    // read into dummy string and increment count
    while (getline(input, dummy)) {
        n++;
    }
    input.close();
    return n;
}

void RLCFilter::readIntoArray(double array[], int n, std::string filename){
    // create an input file stream
    std::ifstream input;
    // use it to open a file named 'MOCK_DATA.csv'
    input.open(filename);
    // check if the file is not open
    if (!input.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error! No input file found!\n";
        exit(1);
    }
    // loop through each line in file
    std::string dummy;
    for (int i = 0; i < n; i++) {
        input >> dummy;
        // read in value, covert to int and write to array
        array[i] = std::stof(dummy);
    }
    input.close();
}

void RLCFilter::writeArrayToFile(double array[], int n, std::string outFilename){
    // create an output file stream
    std::ofstream output;
    // use it to open a file named 'output.txt'
    output.open(outFilename);
    // check if the file is not open
    if (!output.is_open()) {
        // print error message and quit if a problem occurred
        std::cerr << "Error creating file!\n";
        exit(1);
    }
    // loop through and prdouble array
    for (int i = 0; i < n; i++) {
        output << array[i] << std::endl;
    }
    output.close();
}
