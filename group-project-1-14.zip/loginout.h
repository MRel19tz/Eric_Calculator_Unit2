#ifndef LOGINOUT_H
#define LOGINOUT_H

void quit();



#endif