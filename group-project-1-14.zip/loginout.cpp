#include "loginout.h"
#include <iostream>
#include <regex>
#include <cmath>
#include <fstream>
#include <thread>
#include <string>
#include "user.h"


bool is_integer(std::string num);
void quit_menu();
int get_quit_input();




using namespace std;
std::string name;



void quit(){
  User user;
  user.getname();
  quit_menu();
  int input_quit=get_quit_input();
  user.getv(input_quit);
  user.toString();
  int result= input_quit;
  std::cout << "Thank you for your evaluation. Goodbye." <<endl;
  exit(1);
}



void quit_menu(){
  std::cout << "\n\033[46m-----------😸 QUIT 😸-----------\033[40;37m\n";
  std::cout << "\033[46m Please comment on our service. \033[40;37m\n";
  std::cout << "\033[47;30m                                \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   💗💗💗💗💗  Excellent  \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   💗💗💗💗🤍  Good       \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   💗💗💗🤍🤍  Medium     \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   💗💗🤍🤍🤍  Ecumenic   \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   💗🤍🤍🤍🤍  Bad        \033[40;37m\n";
  std::cout << "\033[47;30m                                \033[40;37m\n";
}

int get_quit_input() {
  int input_quit;
  std::string input_string;
  bool valid_input = false;
  int menu_items = 5;

  do {
    std::cout << "\nSelect item ";
    std::cout<<"👉: ";
    std::cin >> input_string;
    valid_input = is_integer(input_string);
    
    // if input is not an integer, print an error message
    if (valid_input == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input_quit = std::stoi(input_string);  // convert to int
      if (input_quit >= 1 && input_quit <= menu_items) {
        valid_input = true;
      } else {
        std::cout << "😔";
        std::cout <<"\033[31m Invalid menu item\033[1;40;37m\n";
        valid_input = false;
      }
    }
  } while (valid_input == false);

  return input_quit;
  
}

