#include<stdio.h>
#include<unistd.h>
#include <iostream>
#include <thread>
#include"outputfile.h"

using namespace std;

void slow_print(const std::string message, int milPerChar);

#define N 50
void read_me_voltage_divider();
void Vin();
void Vout();
void R1();
void R2();
void go_back_to_main();

void go_back_to_voltage_divider();
void select_voltage_divider_item(int input);
void print_voltage_divider_menu();
void voltage_divider_menu();
void voltage_divider();
int get_input_voltagedivider();

//double out;
double vin;
double vout;
double r1;
double r2;

bool is_integer(std::string num);
void terminal_vin(double out);
void file_vin(double out);
void terminal_vout(double out);
void file_vout(double out);
void terminal_r1(double out);
void file_r1(double out);
void terminal_r2(double out);
void file_r2(double out);

void order_array(double array[], int n);
int count_lines_vin();
void read_into_array_vin(double array[], int n);
void write_array_to_file_vin(double array[], int n);
///////////////////////

int count_lines_vout();
void read_into_array_vout(double array[], int n);
void write_array_to_file_vout(double array[], int n);
/////////////////////////

int count_lines_r1();
void read_into_array_r1(double array[], int n);
void write_array_to_file_r1(double array[], int n);
///////////////////////////

int count_lines_r2();
void read_into_array_r2(double array[], int n);
void write_array_to_file_r2(double array[], int n);

void print_voltage_divider_menu(){
    std::cout << "\n\033[44m---- Voltage Divider Page 😀 ----\033[40;37m\n";
  std::cout << "\033[44m                                 \033[40;37m\n";
  std::cout << "\033[47;30m                                 \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   Read me first!🔍        \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   Vin is unknown          \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   Vout is unknown         \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   R1 is unknown           \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   R2 is unknown           \033[40;37m\n";
  std::cout << "\033[47;30m     6️⃣   Back to main menu       \033[40;37m\n";
  std::cout << "\033[47;30m                                 \033[40;37m\n";
}

void voltage_divider_menu(void){
  print_voltage_divider_menu();
  int input = get_input_voltagedivider();
  select_voltage_divider_item(input);
}

void select_voltage_divider_item(int input){
  switch(input)
  {
  case 1: 
    read_me_voltage_divider();
    break;
  case 2: 
    Vin();
    break;
  case 3: 
    Vout();
    break;
  case 4: 
    R1();
    break;
  case 5: 
    R2();
    break;
  case 6: 
    main_menu();
    break;
  default : 
    exit(1);
    break;
  }
}

void go_back_to_voltage_divider() {
  std::string input;
  do {
    std::cout << "\n✨";
    slow_print( "Please enter 'vd' or 'VD' to go back to voltage divider menu: ",60);
    std::cin >> input;
  } while (input != "vd" && input != "VD");
  voltage_divider_menu();
}

void read_me_voltage_divider()
{
    cout <<"\n\033[44m------------------- Read me first ------------------\033[40;37m\n";
  cout << "\033[44m                    🔴🟠🟡🟢🔵🟣                    \033[40;37m\n";
  cout << "\033[47;30m                                                    \033[40;37m\n";
  cout << "\033[47;30m   🟥 This is the simple circuit scheme for voltage \033[40;37m\n";
  
  cout << "\033[47;30m  divider.                                          \033[40;37m\n";
  cout << "\033[47;30m   🟨 To the serial resistors, the principle is     \033[40;37m\n";
  cout << "\033[47;30m                   Vout=R2/(R1+R2)*Vin              \033[40;37m\n";
  cout << "\033[47;30m                                                    \033[40;37m\n";

  cout<<"\033[47;30m  ┏━━━━━━━━━━━━██████━━━━━━━━━━━━━┳━━━━━━━━━━━━     \033[40;37m\n";
  cout<<"\033[47;30m  ┃      ↑       R1               ┃     ↑           \033[40;37m\n";
  cout<<"\033[47;30m  ┃      |                        ┃     |           \033[40;37m\n";
  cout<<"\033[47;30m━━┻━━    Vin                      ┃     Vout        \033[40;37m\n";
  cout<<"\033[47;30m ━┳━     |                    R  ███    |           \033[40;37m\n";
  cout<<"\033[47;30m  ┃      |                    2  ███    |           \033[40;37m\n";
  cout<<"\033[47;30m  ┃      ↓                        ┃     ↓           \033[40;37m\n";
  cout<<"\033[47;30m  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━    \033[40;37m\n";
  cout << "\033[47;30m                                                    \033[40;37m\n";
  go_back_to_voltage_divider();
}

void Vin()
{
    double vin;
    slow_print("Please input value for Vout(float): ",60);
    cin >> vout;
    slow_print("Please input value for R2(float): ",60);
    cin >> r2;
    slow_print("Please input value for R1(float): ",60);
    cin >> r1;
    vin = vout / (r2 / (r1 + r2) ) ;
    double out = vin;
    int input;
    choose_output_menu();
    input = get_input2();
    select_vin_item(input,out);
    go_back_to_voltage_divider();
}

void Vout()
{
    slow_print("Please input value for Vin(float): ",60);
    cin  >> vin;
    slow_print("Please input value for R2(float): ",60);
    cin >> r2;
    slow_print("Please input value for R1(float): ",60);
    cin >> r1;
    double vout;
    vout = vin * r2 / (r1 + r2);
    double out_1 = vout;
    int input;
    choose_output_menu();
    input = get_input2();
    select_vout_item(input,out_1);
    go_back_to_voltage_divider();
    
}

void R1()
{
    slow_print("Please input value for Vin(float): ",60);
    cin  >> vin;
    cout << "⛔Attention! Vout is smaller than Vin⛔ " << endl;
    slow_print("Please input value for Vout(float): ",60);
    cin >> vout;
    slow_print("Please input value for R2(float): ",60);
    cin >> r2;
    double r1;
    r1 = r2/(vin/vout-1);
    double out = r1;
    int input;
    choose_output_menu();
    input = get_input2();
    select_r1_item(input,out);
    go_back_to_voltage_divider();
}

void R2()
{
    slow_print("Please input value for Vin(float): ",60);
    cin  >> vin;
    cout << "⛔Attention! Vout is smaller than Vin⛔ " << endl;
    slow_print("Please input value for Vout(float): ",60);
    cin >> vout;
    slow_print("Please input value for R1(float): ",60);
    cin >> r1;
    double r2;
    r2 = r1/(vin/vout-1);
    //r2 = (r2*(-1) - r1);
    //cout << ha << endl;
     double out_2 = r2;
    int input;
    choose_output_menu();
    input = get_input2();
    select_r2_item(input,out_2);
    go_back_to_voltage_divider();
}

void voltage_divider(){
  cout << "\033[44m---- Welcome to use Voltage Divider Calculator----   \033[40;37m\n";
  voltage_divider_menu();
  system("color F4");
}

void select_vin_item(int input,double out) {
  switch (input) {
    case 1:
    terminal_vin(out);
      break;
    case 2:
      file_vin(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_vin (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_vin (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Vin.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to Vin.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_vin();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_vin(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_vin(array, n);
  }
}

int count_lines_vin() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("Vin.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_vin(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("Vin.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}


void write_array_to_file_vin(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Vin_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cout<< "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

//////
/////vout
void select_vout_item(int input,double out) {
  switch (input) {
    case 1:
    terminal_vout(out);
      break;
    case 2:
      file_vout(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_vout (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_vout (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Vout.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to Vout.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_vout();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_vout(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_vout(array, n);
  }
}

int count_lines_vout() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("Vout.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_vout(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("Vout.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}


void write_array_to_file_vout(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("Vout_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}

//////
//////r1
void select_r1_item(int input,double out) {
  switch (input) {
    case 1:
    terminal_r1(out);
      break;
    case 2:
      file_r1(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_r1 (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_r1 (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("r1.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cout << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to r1.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_r1();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_r1(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_r1(array, n);
  }
}

int count_lines_r1() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("r1.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_r1(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("r1.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}


void write_array_to_file_r1(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("r1_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}
//////
/////r2
void select_r2_item(int input,double out) {
  switch (input) {
    case 1:
    terminal_r2(out);
      break;
    case 2:
      file_r2(out);
      break;
    default:
      exit(1);
      break;
  }
}

void terminal_r2 (double out){
  std::cout <<"The value of you want is " << out <<std::endl;
}

void file_r2 (double out){
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("r2.txt",std::fstream::app);
  // check if the file is not open
  if (!output.is_open()) {
  // print error message and quit if a problem occurred
   std::cerr << "Error creating file!\n";
  exit(1);
  }
  // print to the file and then close the stream
  output << out << std::endl;
  output.close();
  std::cout <<"Congratulations！The value you need is loaded to r2.txt, Please check it~💕\n";
  std::cout <<"If you wana sort the data in the txt file, please enter 9 😃: ";
  int input3;
  std::cin >> input3;
 if(input3 == 9){
  int n = count_lines_r2();
  double *array = new double[n];
  // read the random numbers into the array
  read_into_array_r2(array, n);
  // order the values in the array
  order_array(array, n);
  // then write ordered values to file 'ordered.txt'
  write_array_to_file_r2(array, n);
  }
}
int count_lines_r2() {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'random.txt'
  input.open("r2.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cerr << "Error! No input file found!\n";
    exit(1);
  }
  int n = 0;
  std::string dummy;
  // keep reading lines in file until no lines left to read
  // read into dummy string and increment count
  while (getline(input, dummy)) {
    n++;
  }
  input.close();
  return n;
}

void read_into_array_r2(double array[], int n) {
  // create an input file stream
  std::ifstream input;
  // use it to open a file named 'MOCK_DATA.csv'
  input.open("r2.txt");
  // check if the file is not open
  if (!input.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error! No input file found!\n";
    exit(1);
  }
  // loop through each line in file
  std::string dummy;
  for (int i = 0; i < n; i++) {
    input >> dummy;
    // read in value, covert to int and write to array
    array[i] = std::stof(dummy);
  }
  input.close();
}


void write_array_to_file_r2(double array[], int n) {
  // create an output file stream
  std::ofstream output;
  // use it to open a file named 'output.txt'
  output.open("r2_ordered.txt");
  // check if the file is not open
  if (!output.is_open()) {
    // print error message and quit if a problem occurred
    std::cout << "Error creating file!\n";
    exit(1);
  }
  // loop through and prdouble array
  for (int i = 0; i < n; i++) {
    output << array[i] << std::endl;
  }
  output.close();
}