#ifndef CONVERTER_H
#define CONVERTER_H

#include <string>
#include <iostream>
#include <bitset>
#include <cmath>
#include <stdio.h>
#include <regex>

class Converter
{
public:
    Converter();
    void setInput(int input);
    void setNumber(int number);
    void setBOuput(std::string boutput);
    void setOOutput(std::string ooputput);
    void setHOputput(std::string houput);
    void terminal();


private:
    int m_input;
    long int m_number;
};

#endif // CONVERTER_H

