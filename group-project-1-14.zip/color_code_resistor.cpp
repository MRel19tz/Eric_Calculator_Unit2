#include<stdio.h>
#include<math.h>
#include <iostream>
#include<string.h>
using namespace std;

#define N 50
void Color_ring_resistance();
void four_bands();
void five_bands();
void six_bands();
int k,p,l,Val;

void slow_print(const std::string message, int milPerChar);
void main_menu();
void Read_me_color_ring();
void go_back_to_colour_ring();
void print_colour_ring_menu();
void select_colour_ring_item(int input3);
void colour_ring_menu();
int get_input_colour_ring();
bool is_integer(std::string num);

void Read_me_color_ring() {
  std::cout <<"\n\033[44m------------------------ Read me first -----------------------\033[40;37m\n";
  std::cout << "\033[44m                          🔴🟠🟡🟢🔵🟣                        \033[40;37m\n";
  std::cout << "\033[47;30m                                                              \033[40;33m\n";
  std::cout << "\033[47;30m 🟥 Welcome to colour ring resistance calculator.             \033[40;37m\n";
  std::cout << "\033[47;30m 🟨 Four bands, five bands and six bands are all available.   \033[40;37m\n";
  std::cout << "\033[47;30m 🟩 The information about colour and its corresponding        \033[40;37m\n";
  std::cout << "\033[47;30m   number is in Read Me.                                      \033[40;37m\n";
  std::cout << "\033[47;30m 🟦 Can choose to print the calculated values on the terminal \033[40;37m\n";
  std::cout << "\033[47;30m    or txt file, and sort the data according to the needs.    \033[40;37m\n";
  std::cout << "\033[47;30m                                                              \033[40;33m\n";

        cout<<"This is the input of the digit bands  \n";
        cout<<"\033[0;37;40m 0 \033[0m BLK=B \n";
        cout<<"\033[0;30;43m 1 \033[0m BRN=N \n";
        cout<<"\033[0;30;41m 2 \033[0m RED=R \n";
        cout<<"\033[0;30;42m 3 \033[0m GRN=G \n";
        cout<<"\033[0;31;40m 4 \033[0m ORN=O \n";
        cout<<"\033[0;33;40m 5 \033[0m YEL=Y \n";
        cout<<"\033[0;30;44m 6 \033[0m BLU=L \n";
        cout<<"\033[0;30;45m 7 \033[0m VIO=V \n";
        cout<<"\033[0;30;46m 8 \033[0m GRY=E \n";
        cout<<"\033[0;30;47m 9 \033[0m WHT=W \n";



        cout<<"This is the input of tolerance band  \n";
        cout<<"\033[0;37;40m  10p \033[0m SLV=SLV \n";
        cout<<"\033[0;30;43m   5p \033[0m GLD=GLD \n";
        cout<<"\033[0;30;41m   2p \033[0m RED=R \n";
        cout<<"\033[0;30;42m 0.5p \033[0m GRN=G \n";      
        cout<<"\033[0;33;40m   1p \033[0m BRN=N \n";
        cout<<"\033[0;30;44m 0.25p\033[0m BLU=L \n";
        cout<<"\033[0;30;45m 0.1p \033[0m VIO=V \n";

        cout<<"This is the input of temperature band  \n";
        cout<<"\033[0;31;40m  15PPM \033[0m ORN=O \n";
        cout<<"\033[0;30;41m  50PPM \033[0m RED=R \n";
        cout<<"\033[0;30;43m  25PPM \033[0m YEL=Y \n";    
        cout<<"\033[0;33;40m 100PPM \033[0m BRN=N \n";



  go_back_to_colour_ring();
  system("color F4");
}


void go_back_to_colour_ring() {
  std::string input;
  do {
    std::cout << "\n💥 ";
    slow_print( "Please enter 're' or 'RE' to go back to colour ring resistance menu: ",60);
    std::cin >> input;
  } while (input != "re" && input != "RE");
  colour_ring_menu();
}


void print_colour_ring_menu() {
  std::cout << "\n\033[44m---- Colour Code Resistor  ----\033[40;37m\n";
  std::cout << "\033[44m        Select Page 😀         \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";
  std::cout << "\033[47;30m     1️⃣   Read me first!🔍      \033[40;37m\n";
  std::cout << "\033[47;30m     2️⃣   4  Bands              \033[40;37m\n";
  std::cout << "\033[47;30m     3️⃣   5  Bands              \033[40;37m\n";
  std::cout << "\033[47;30m     4️⃣   6  Bands              \033[40;37m\n";
  std::cout << "\033[47;30m     5️⃣   Back to main menu     \033[40;37m\n";
  std::cout << "\033[47;30m                               \033[40;37m\n";

}


void select_colour_ring_item(int input3){
  switch(input3)
  {
  case 1: 
    Read_me_color_ring();
    break;
  case 2: 
    four_bands();
    break;
  case 3: 
    five_bands();
    break;
  case 4: 
    six_bands();
    break;
  case 5: 
    main_menu();
    break;
  default : 
    exit(1);
    break;
  }
}


void colour_ring_menu(){
  print_colour_ring_menu();
  int input = get_input_colour_ring();
  select_colour_ring_item(input);
}

int get_input_colour_ring(){
  int input3;
  std::string input3_string;
  bool valid_input3 = false;
  int menu_items = 5;
  do {
    slow_print( "\nSelect item ",60);
    std::cout<<"👉: ";
    std::cin >> input3_string;
    valid_input3 = is_integer(input3_string);
    // if input is not an integer, print an error message
    if (valid_input3 == false) {
      std::cout << "Please enter an integer to select which component to calculate:\n";
    } else {  // if it is an int, check whether in range
      input3 = std::stof(input3_string);
    }
      if (input3 >= 1 && input3 <= menu_items) {
        valid_input3 = true;
      } else {
        std::cout << "😔 ";
        std::cout << "\033[1;40;31m Invalid menu item\033[1;40;37m\n";
      }
    } while (valid_input3 == false);
  return input3;
}


void four_bands(){
float Val; 
float m; 
float n; 
float p; 
string i,j,k,t,q;
cout<<"Please input the colour for digit 1: ";
cin>>i; 
if(i=="B"){
m=0;
}
if(i=="N"){
m=1;
}
if(i=="R"){
m=2;
}
if(i=="O"){
m=3;
}
if(i=="Y"){
m=4;
}
if(i=="G"){
m=5;
}
if(i=="L"){
m=6;
}
if(i=="V"){
m=7;
}
if(i=="E"){
m=8;
}
if(i=="W"){
m=9;
}
cout<<"Please input the colour for digit 2: "; 
cin>>j;
if(j=="B"){
n=0;
}
if(j=="N"){
n=1;
}
if(j=="R"){
n=2;
}
if(j=="O"){
n=3;
}
if(j=="Y"){
n=4;
}
if(j=="G"){
n=5;
}
if(j=="L"){
n=6;
}
if(j=="V"){
n=7;
}
if(j=="E"){
n=8;
}
if(j=="W"){
n=9;
} 
cout<<"Please input the colour for the multiplier: ";
cin>>k;
if(k=="SLV"){
p=0.01;
}
if(k=="GLD"){
p=0.1;
}
if(k=="B"){
p=0;
}
if(k=="N"){
p=1;
}
if(k=="R"){
p=2;
}
if(k=="O"){
p=3;
}
if(k=="Y"){
p=4;
}
if(k=="G"){
p=5;
}
if(k=="L"){
p=6;
}
if(k=="V"){
p=7;
}
cout<<"Please input the colour for tolerance: "; 
cin>>t;
if(t=="SLV"){
q="+-10%";
}
  if(t=="GLD"){
  q="+-5%";
  }
  if(t=="N"){
  q="+-1%";
  }
  if(t=="R"){
  q="+-2%";
  }
  if(t=="G"){
  q="+-0.5%";
  }
  if(t=="L"){
  q="+-0.25%";
  }
  if(t=="V"){
  q="+-0.1%";
  }
  Val=((10*m)+n)*(pow(10,p));
  cout<<"Value = "<<Val<<"( "<<q<<") ""Ohm"<<endl; go_back_to_colour_ring();
}




void five_bands(){
float Val,m,n,p,h; 
string i,j,k,w,t,q;
cout<<"Please input the colour for digit 1: ";
cin>>i; 
if(i=="B"){
m=0;
}
if(i=="N"){
m=1;
}
if(i=="R"){
m=2;
}
if(i=="O"){
m=3;
}
if(i=="Y"){
m=4;
}
if(i=="G"){
m=5;
}
if(i=="L"){
m=6;
}
if(i=="V"){
m=7;
}
if(i=="E"){
m=8;
}
if(i=="W"){
m=9;
}
cout<<"Please input the colour for digit 2: "; 
cin>>j;
if(j=="B"){
n=0;
}
if(j=="N"){
n=1;
}
if(j=="R"){
n=2;
}
if(j=="O"){
n=3;
}
if(j=="Y"){
n=4;
}
if(j=="G"){
n=5;
}
if(j=="L"){
n=6;
}
if(j=="V"){
n=7;
}
if(j=="E"){
n=8;
}
if(j=="W"){
n=9;
} 
cout<<"Please input the colour for digit 3: ";
cin>>i; 
if(w=="B"){
h=0;
}
if(w=="N"){
h=1;
}
if(w=="R"){
h=2;
}
if(w=="O"){
h=3;
}
if(w=="Y"){
h=4;
}
if(w=="G"){
h=5;
}
if(w=="L"){
h=6;
}
if(w=="V"){
h=7;
}
if(w=="E"){
h=8;
}
if(w=="W"){
h=9;
}
cout<<"Please input the colour for the multiplier: ";
cin>>k;
if(k=="SLV"){
p=0.01;
}
if(k=="GLD"){
p=0.1;
}
if(k=="B"){
p=0;
}
if(k=="N"){
p=1;
}
if(k=="R"){
p=2;
}
if(k=="O"){
p=3;
}
if(k=="Y"){
p=4;
}
if(k=="G"){
p=5;
}
if(k=="L"){
p=6;
}
if(k=="V"){
p=7;
}

cout<<"Please input the colour for tolerance: "; 
cin>>t;
if(t=="SLV"){
q="+-10%";
}
if(t=="GLD"){
q="+-5%";
}

if(t=="N"){
q="+-1%";
}
if(t=="R"){
q="+-2%";
}

if(t=="G"){
q="+-0.5%";
}
if(t=="L"){
q="+-0.25%";
}
if(t=="V"){
q="+-0.1%";
}
Val=((100*m)+(10*n)+h)*(pow(10,p));
cout<<"The Value of resistor is "<<Val<<"("<<q<<") ""Ohm"<<endl;
go_back_to_colour_ring();
} 







void six_bands(){
float Val,m,n,p,h; 
string i,j,k,w,t,q,s,d;
cout<<"Please input the colour for digit 1: ";
cin>>i; 
if(i=="B"){
m=0;
}
if(i=="N"){
m=1;
}
if(i=="R"){
m=2;
}
if(i=="O"){
m=3;
}
if(i=="Y"){
m=4;
}
if(i=="G"){
m=5;
}
if(i=="L"){
m=6;
}
if(i=="V"){
m=7;
}
if(i=="E"){
m=8;
}
if(i=="W"){
m=9;
}
cout<<"Please input the colour for digit 2: "; 
cin>>j;
if(j=="B"){
n=0;
}
if(j=="N"){
n=1;
}
if(j=="R"){
n=2;
}
if(j=="O"){
n=3;
}
if(j=="Y"){
n=4;
}
if(j=="G"){
n=5;
}
if(j=="L"){
n=6;
}
if(j=="V"){
n=7;
}
if(j=="E"){
n=8;
}
if(j=="W"){
n=9;
} 
cout<<"Please input the colour for digit 3: ";
cin>>i; 
if(w=="B"){
h=0;
}
if(w=="N"){
h=1;
}
if(w=="R"){
h=2;
}
if(w=="O"){
h=3;
}
if(w=="Y"){
h=4;
}
if(w=="G"){
h=5;
}
if(w=="L"){
h=6;
}
if(w=="V"){
h=7;
}
if(w=="E"){
h=8;
}
if(w=="W"){
h=9;
}
cout<<"Please input the colour for the multiplier: ";
cin>>k;
if(k=="SLV"){
p=0.01;
}
if(k=="GLD"){
p=0.1;
}
if(k=="B"){
p=0;
}
if(k=="N"){
p=1;
}
if(k=="R"){
p=2;
}
if(k=="O"){
p=3;
}
if(k=="Y"){
p=4;
}
if(k=="G"){
p=5;
}
if(k=="L"){
p=6;
}
if(k=="V"){
p=7;
}

cout<<"Please input the colour for tolerance: "; 
cin>>t;
if(t=="SLV"){
q="+-10%";
}
if(t=="GLD"){
q="+-5%";
}

if(t=="N"){
q="+-1%";
}
if(t=="R"){
q="+-2%";
}

if(t=="G"){
q="+-0.5%";
}
if(t=="L"){
q="+-0.25%";
}
if(t=="V"){
q="+-0.1%";
}

cout<<"Please input the colour for temperature coefficients: "; 
cin>>s;
if(s=="N"){
d="100PPM";
}
else if(s=="R"){
d="50PPM";
}
else if(s=="O"){
d="15PPM";
}
else if(s=="Y"){
d="25PPM";
}
else{
  cout<<"Please provide the correct letter."<<endl;
}

Val=((100*m)+(10*n)+h)*(pow(10,p));
cout<<"The Value of resistor is "<<Val<<"("<<q<<") ""Ohm"<<endl;
cout<<"The temperature coefficient is "<<d<<endl;
go_back_to_colour_ring();
}